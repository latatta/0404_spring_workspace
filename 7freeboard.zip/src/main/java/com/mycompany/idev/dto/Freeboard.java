package com.mycompany.idev.dto;

public class Freeboard {

}
